<?php
//Do we know the user's name?
session_start();
$user_name = $_SESSION['user name'];
if ( $user_name == '' ) {
  header('location:ask-user-name.html');
  exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Strict//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Kieran Photo | Sessions Sample App</title>
  </head>
  <body>
    <div id="container">
      <p><img src="kieran.jpg" alt="CC"></p>
      <h1 class="loves">Kieran loves <?php print $user_name; ?></h1>
    </div>
    <p><a href="menu.php">&lt; Menu</a></p>
  </body>
</html>
