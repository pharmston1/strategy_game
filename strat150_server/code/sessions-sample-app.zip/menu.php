<?php
//Do we know the user's name?
session_start();
$user_name = $_SESSION['user name'];
if ( $user_name == '' ) {
  header('location:ask-user-name.html');
  exit();
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Strict//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <title>Menu</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  </head>
  <body>
    <h1>Menu</h1>
    <p>Name: <?php print $user_name; ?></p>
    <ul>
      <li><a href="cc.php">CC photo</a></li>
      <li><a href="kieran.php">Kieran photo</a></li>
      <li><a href="renata.php">Renata photo</a></li>
      <li><a href="new-name.php">Use a different name</a></li>
    </ul>
  </body>
</html>
